# SAOD
laboratornaya
[![Run on Repl.it](https://repl.it/badge/github/Andruscha-ai/SAOD)](https://repl.it/github/Andruscha-ai/SAOD)